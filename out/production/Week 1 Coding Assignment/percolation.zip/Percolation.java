import edu.princeton.cs.algs4.WeightedQuickUnionUF;

public class Percolation {

    private boolean[][] site;
    private int n;
    private int countOpen;
    private WeightedQuickUnionUF d;
    private WeightedQuickUnionUF d2;
    private int top;
    private int bottom;

    public Percolation(int n) {
        if (n <= 0)
            throw new IllegalArgumentException("Wrong value of N");
        else {
            d = new WeightedQuickUnionUF(n*n + 2);
            d2 = new WeightedQuickUnionUF(n*n + 1);
            site = new boolean[n+2][n+2];
            countOpen = 0;
            this.n = n;
            top = n*n;
            bottom = n*n+1;
        }
    }

    // opens the site (row, col) if it is not open already
    private boolean checkIndex(int row, int col) {
        if (row < 1 || row > n || col < 1 || col > n) return false;
        else return true;
    }
    public void open(int row, int col) {
        if (!checkIndex(row, col)) {
            throw new IllegalArgumentException("outside of prescribed range");
        } else {
            if (!site[row][col]) {
                site[row][col] = true;
                countOpen++;
            }
            if (site[row][col+1]) {
                d.union((row - 1) * n + col - 1, (row - 1) * n + col);
                d2.union((row - 1) * n + col - 1, (row - 1) * n + col);
            }
            if (site[row][col - 1]) {
                d.union((row - 1) * n + col - 1, (row - 1) * n + col - 2);
                d2.union((row - 1) * n + col - 1, (row - 1) * n + col - 2);
            }
            if (site[row + 1][col]) {
                d.union((row - 1) * n + col - 1, (row) * n + col - 1);
                d2.union((row - 1) * n + col - 1, (row) * n + col - 1);
            }
            if (site[row - 1][col]) {
                d.union((row - 1) * n + col - 1, (row - 2) * n + col - 1);
                d2.union((row - 1) * n + col - 1, (row - 2) * n + col - 1);
            }
            for (int i = 0; i < n; i++) {
                d.union(i, top);
                d2.union(i, top);
            }
            for (int i = n*(n-1); i < n*n; i++)
                d.union(i, bottom);
        }
    }

    // is the site (row, col) open?
    public boolean isOpen(int row, int col) {
        if (!checkIndex(row, col))
            throw new IllegalArgumentException("outside of prescribed range");
        else return site[row][col];
    }

    // is the site (row, col) full?
    public boolean isFull(int row, int col) {
        if (!checkIndex(row, col))
            throw new IllegalArgumentException("outside of prescribed range");
        else if (isOpen(row, col))
            return d2.find(n * (row - 1) + (col - 1)) == d2.find(n * n);
        return false;
    }

    // returns the number of open sites
    public int numberOfOpenSites() {
        return countOpen;
    }

    // does the system percolate?
    public boolean percolates() {
        int topRoot = d.find(n*n);
        int bottomRoot = d.find(n*n+1);
        return topRoot == bottomRoot;
    }

    public static void main(String[] args) {
    }
}